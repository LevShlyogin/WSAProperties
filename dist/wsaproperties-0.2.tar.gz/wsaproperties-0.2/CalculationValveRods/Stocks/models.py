class ClapanModel:
    pass
